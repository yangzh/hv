import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Refer to https://github.com/kubernetes-client/python for an example for defining a Python package.
setuptools.setup(
    name="kongming",
    version="1.1.0",
    description="Python modules for high-dimensional computing, by Kongming Studio.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Kevin Yang",
    author_email="yangzh@gmail.com",
    license="MIT License",
    keywords=["VSA", "Hyper-Dimensional Computing", "HDC"],
    url="https://kongming.app",
    classifiers=[
        "Development Status :: 3 - Alpha",

        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",

        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries",

        "License :: OSI Approved :: MIT License",

        "Programming Language :: Python :: 3",

        "Operating System: POSIX :: Linux (x86_64)",
    ],
    python_requires=">=3.7, <4",
    packages=[
        "kongming",
        "kongming.api",
        "kongming.ext",
        "kongming.hv",
        ],
    install_requires=[
        "absl-py",  # Common Python module, gflags particularly.
        "protobuf",
        "grpcio",
        "googleapis-common-protos",
        "spacy",
        "stanza",
        ],
    include_package_data=True,
)