# Python package for high-dimensional computing, by Kongming Studio.

License: MIT License (see LICENSE)

The package contains the following packages:

* kongming.api: the Python binding for underlying [protocol buffer](https://developers.google.com/protocol-buffers) definitions;

* kongming.imported: it contains the hyper-vector (`hv`) Python extension module.
The heavy-lifting operation was performed in Go, and we use `github.com/go-python/gopy` to inter-operate with Python. 

* kongming.util: utility Python code to manipulate hyper-vectors with more Pythonic interfaces.