from kongming import api, hv, memory 

from .local import LocalMemory

d0 = hv.d0()
so = d0.new_sparse_operation(api.MODEL_10BIT, 100)

m = LocalMemory()

with m.session() as m:
    codes = {}
    for c in range(ord('a'), ord('z')+1):
        chunk = m.set(memory.terminal_code(chr(c), '', None))
        codes[c] = hv.extract_code(chunk)

    word = d0.new_sequence(
        codes[ord('w')], codes[ord('o')], codes[ord('r')], codes[ord('l')], codes[ord('d')])
    m.set(memory.from_sequence(word, "test", "", None))
