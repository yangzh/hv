from contextlib import contextmanager

from kongming.hv import helpers

from ..ext import hv, memory, badger

from ..api import memory_pb2
from ..api import chunk_pb2

@contextmanager
def managed_local_memory(path: str, read_only: bool):
    ctx = hv.background()
    m = badger.connect(ctx, path, read_only, None)
    try:
        yield LocalMemory(m) 
    finally:
        m.close(ctx)

class LocalMemory():
    """LocalMemory is a wrapper for 'memory.Memory' that provides Pythonic API.
    """
    def __init__(self, core: memory.Memory):
        self._core = core 

    def name(self)-> str:
        return self._core.name()

    def id(self)-> int:
        return self._core.id()

    def opt(self)-> memory_pb2.MemoryOpt:
        return helpers.to_native_msg("MemoryOpt", self._core.opt())

    def substrate(self)-> memory.Substrate:
        raise NotImplementedError

    def get(self, picker: memory.CodePicker)-> list[chunk_pb2.Chunk]:
        resp = self._core.get(None, picker, None)
        native_resp = helpers.to_native_msg("GetResponse", resp)
        return native_resp.read

    def set(self, producer: memory.ChunkProducer)-> chunk_pb2.Chunk:
        resp = self._core.set(None, producer, None)
        native_resp = helpers.to_native_msg("SetResponse", resp)
        return native_resp.written

