from contextlib import contextmanager
import grpc

from kongming.hv import helpers

from ..ext import memory
from ..api import aletheia_pb2
from ..api import aletheia_pb2_grpc
from ..api import chunk_pb2

@contextmanager
def managed_remote_memory(target: str, credentials=None):
    if credentials is None:
        channel = grpc.insecure_channel(target)
    else:
        channel = grpc.secure_channel(target, credentials)

    with channel:
        stub = aletheia_pb2_grpc.AletheiaServiceStub(channel)
        # Perform initial request to retriev name/id from the remote memory service.
        yield RemoteMemory(stub)


class RemoteMemory():
    """MemoryStub represents a local agent that interacts with a remote memory service.

    The 'remote' memory can be located anywhere, even locally. However, the communication is done through gRPC.
    """
    def __init__(self, stub):
        self._stub = stub 

    def get(self, picker: aletheia_pb2.CodePickerProto | memory.CodePicker, session: aletheia_pb2.Session=None)-> list[chunk_pb2.Chunk]:
        """get gets all chunks that matches the criteria implied by picker.
        """
        try:
            if isinstance(picker, aletheia_pb2.CodePickerProto):
                picker_msg = picker
            elif isinstance(picker, memory.CodePicker):
                picker_msg = helpers.to_native_msg("CodePickerProto", picker.proto_load())
            else:
                raise ValueError

            resp = self._stub.Get(aletheia_pb2.GetRequest(picker=picker_msg, session=session))
            return resp.read
        except grpc.RpcError as e:
            print(e.details())

    def set(self, producer: aletheia_pb2.ChunkProducerProto | memory.ChunkProducer, session: aletheia_pb2.Session=None)-> chunk_pb2.Chunk:
        """set sets the chunk produced by producer, return the chunk upon success.
        """
        try:
            if isinstance(producer, aletheia_pb2.ChunkProducerProto):
                producer_msg = producer
            elif isinstance(producer, memory.ChunkProducer):
                producer_msg = helpers.to_native_msg("ChunkProducerProto", producer.proto_load())
            else:
                raise ValueError

            resp = self._stub.Set(aletheia_pb2.SetRequest(producer=producer_msg, session=session))
            return resp.written
        except grpc.RpcError as e:
            print(e.details)
