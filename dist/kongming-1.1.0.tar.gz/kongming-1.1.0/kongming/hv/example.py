from collections import namedtuple

from ..ext import hv

MexicanDollarPackage = namedtuple('MexicanDollarPackage', [
    'country_code_marker', 'country_codes',
    'capital_marker', 'capitals',
    'currency_marker', 'currencies',
    'encoded',
])

def mexican_dollar(so: hv.SparseOperation, silent: bool = False)-> MexicanDollarPackage:
    # get the associated domain with supplied `so` instance.
    domain = so.domain()

    country_code_marker = domain.new_random_sparse_segmented(so)
    country_codes = {
        'usa': domain.new_random_sparse_segmented(so),
        'mex': domain.new_random_sparse_segmented(so),
        'swe': domain.new_random_sparse_segmented(so),
    }
    capital_marker = domain.new_random_sparse_segmented(so)
    capitals = {
        'washington_dc': domain.new_random_sparse_segmented(so),
        'mexico_city': domain.new_random_sparse_segmented(so),
        'stockholm': domain.new_random_sparse_segmented(so),
    }
    currency_marker = domain.new_random_sparse_segmented(so)
    currencies = {
        'dollar': domain.new_random_sparse_segmented(so),
        'peso': domain.new_random_sparse_segmented(so),
        'krona': domain.new_random_sparse_segmented(so),
    }
    encoded = {
        'us': domain.bundle(
            0,
            domain.bind(country_code_marker, country_codes['usa']),
            domain.bind(capital_marker, capitals['washington_dc']),
            domain.bind(currency_marker, currencies['dollar'])),
        'mexico': domain.bundle(
            0,
		    domain.bind(country_code_marker, country_codes['mex']),
            domain.bind(capital_marker, capitals['mexico_city']),
            domain.bind(currency_marker, currencies['peso'])),
        'sweden': domain.bundle(
            0,
		    domain.bind(country_code_marker, country_codes['swe']),
            domain.bind(capital_marker, capitals['stockholm']),
            domain.bind(currency_marker, currencies['krona'])),
        }

    if not silent:
        transfer_to_mexico = domain.release(encoded['mexico'], encoded['us'])
        mexican_dollar = domain.bind(currencies['dollar'], transfer_to_mexico)
        print(f"What's the dollar of Mexico: guess={mexican_dollar}, O(guess, 'peso')={hv.overlap(mexican_dollar, currencies['peso'])}")
        mexican_dc = domain.bind(capitals['washington_dc'], transfer_to_mexico)
        print(f"What's the DC of Mexico: guess={mexican_dc}, O(guess, 'mexico_city')={hv.overlap(mexican_dc, capitals['mexico_city'])}")
        mexican_usa = domain.bind(country_codes['usa'], transfer_to_mexico)
        print(f"What's the USA label of Mexico: guess={mexican_usa}, O(guess, 'mex')={hv.overlap(mexican_usa, country_codes['mex'])}")

        transfer_to_sweden = domain.release(encoded['sweden'], encoded['us'])
        sweden_dollar = domain.bind(currencies['dollar'], transfer_to_sweden)
        print(f"What's the dollar of Sweden: guess={sweden_dollar}, O(guess, 'krona')={hv.overlap(sweden_dollar, currencies['krona'])}")
        sweden_dc = domain.bind(capitals['washington_dc'], transfer_to_sweden)
        print(f"What's the DC of Sweden: guess={sweden_dc}, O(guess, 'stockholm')={hv.overlap(sweden_dc, capitals['stockholm'])}")
        sweden_usa = domain.bind(country_codes['usa'], transfer_to_sweden)
        print(f"What's the USA label of Mexico: guess={sweden_usa}, O(guess, 'swe')={hv.overlap(sweden_usa, country_codes['swe'])}")

    return MexicanDollarPackage(
        country_code_marker, country_codes,
        capital_marker, capitals,
        currency_marker, currencies,
        encoded)
