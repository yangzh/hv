from collections import namedtuple 

from ..ext import hv

MexicanDollarPackage = namedtuple('MexicanDollarPackage', [
        'country_code_marker', 'country_codes', 
        'capital_marker', 'capitals',
        'currency_marker', 'currencies',
        'encoded',
    ])

def mexican_dollar(so: hv.SparseOperation, silent: bool = False)-> MexicanDollarPackage:
    d0=hv.d0()
    country_code_marker = d0.new_random_sparse_segmented(so)
    country_codes = {
        'usa': d0.new_random_sparse_segmented(so),
        'mex': d0.new_random_sparse_segmented(so),
        'swe': d0.new_random_sparse_segmented(so),
    }
    capital_marker = d0.new_random_sparse_segmented(so)
    capitals = {
        'washington_dc': d0.new_random_sparse_segmented(so),
        'mexico_city': d0.new_random_sparse_segmented(so),
        'stockholm': d0.new_random_sparse_segmented(so),
    }
    currency_marker = d0.new_random_sparse_segmented(so)
    currencies = {
        'dollar': d0.new_random_sparse_segmented(so),
        'peso': d0.new_random_sparse_segmented(so),
        'krona': d0.new_random_sparse_segmented(so),     
    }
    encoded = {
        'us': d0.bundle(
            0,
            d0.bind(country_code_marker, country_codes['usa']), 
            d0.bind(capital_marker, capitals['washington_dc']), 
            d0.bind(currency_marker, currencies['dollar'])),
        'mexico': d0.bundle(
            0,
		    d0.bind(country_code_marker, country_codes['mex']), 
            d0.bind(capital_marker, capitals['mexico_city']), 
            d0.bind(currency_marker, currencies['peso'])),
        'sweden': d0.bundle(
            0,
		    d0.bind(country_code_marker, country_codes['swe']), 
            d0.bind(capital_marker, capitals['stockholm']), 
            d0.bind(currency_marker, currencies['krona'])),
        }

    if not silent:
        mexican_dollar = d0.bind(currencies['dollar'], d0.release(encoded['mexico'], encoded['us']))
        print(f"What's the dollar of Mexico: guess={mexican_dollar}, O(guess, peso)={hv.overlap(mexican_dollar, currencies['peso'])}")

    return MexicanDollarPackage(
        country_code_marker, country_codes,
        capital_marker, capitals,
        currency_marker, currencies,
        encoded)
