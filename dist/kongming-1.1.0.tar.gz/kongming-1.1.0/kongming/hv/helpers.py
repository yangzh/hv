from google.protobuf import message

from kongming import api

from ..ext.hv import *
from ..ext import go

def from_native_msg(name: str, msg: message.Message)-> go.protoreflect_ProtoMessage:
    if msg is None:
        return None

    container = new_proto_msg(name)
    unmarshal(msg.SerializeToString(), container)
    return container

def to_native_msg(name: str, msg: go.protoreflect_ProtoMessage)-> message.Message:
    if msg is None:
        return None

    msg_constructor = api.__dict__.get(name)
    if not msg_constructor:
        return None

    container = msg_constructor()
    container.ParseFromString(bytes(marshal(msg)))
    return container


def to_native_hbp(msg: go.protoreflect_ProtoMessage)-> message.Message:
    """shortcut for to_native_msg("HyperBinaryProto", msg)
    """
    return to_native_msg("HyperBinaryProto", msg)

def to_native_hbsp(msg: go.protoreflect_ProtoMessage)-> message.Message:
    """shortcut for to_native_msg("HyperBinarySetProto", msg)
    """
    return to_native_msg("HyperBinarySetProto", msg)

def weights(weights: list[float], normalize=False)-> go.Slice_float64:
    """weights is used to supply a list of weight into underlying Go methods that expects weights.
    """
    if normalize and sum(weights) != 1:
        raise ValueError("weights not normalized?")

    return go.Slice_float64(weights)
