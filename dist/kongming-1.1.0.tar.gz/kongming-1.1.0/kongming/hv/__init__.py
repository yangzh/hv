from ..ext.hv import *

from .. import api
from ..ext import go

def to_message(hb: HyperBinary)-> api.HyperBinaryProto:
    """to_message converts a HyperBinary instance into its equivalent protobuf message.
    """
    serialized = serialize(hb)

    hbp = api.HyperBinaryProto()
    hbp.ParseFromString(bytes(serialized))
    return hbp

def to_set_message(hbs: HyperBinarySet)-> api.HyperBinarySetProto:
    """to_set_message converts a HyperBinarySet instance into its equivalent protobuf message.
    """
    serialized = serialize_set(hbs)

    hbsp = api.HyperBinarySetProto()
    hbsp.ParseFromString(bytes(serialized))
    return hbsp 

def from_message(hbp: api.HyperBinaryProto)-> HyperBinary:
    """from_message converts a HyperBinaryProto message into its equivalent HyperBinary instance.
    """
    serialized = hbp.SerializeToString()
    return deserialize(go.Slice_byte(serialized))

def from_set_message(hbsp: api.HyperBinarySetProto)-> HyperBinarySet:
    """from_set_message converts a HyperBinarySetProto message into its equivalent HyperBinarySet instance.
    """
    serialized = hbsp.SerializeToString()
    return deserialize_set(go.Slice_byte(serialized))
