from kongming import hv 
from kongming.api import hv_pb2 

d = hv.d0()
so = d.new_sparse_operation(2, 99)
a = d.new_random_sparse_segmented(so)

b = a.proto_load()

back = hv.to_native_msg("HyperBinaryProto", b)
print(back)
